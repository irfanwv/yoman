'use strict';

/**
 * @ngdoc overview
 * @name yomanApp
 * @description
 * # yomanApp
 *
 * Main module of the application.
 */
angular
  .module('yomanApp')
  .config(function ($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true).hashPrefix('!');
    $routeProvider
      .when('about', {
        url:'about',
        templateUrl: 'scripts/about/about.html',
        controller: 'aboutCtrl',
        controllerAs: 'ab'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
