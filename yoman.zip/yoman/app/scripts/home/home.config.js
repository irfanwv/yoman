'use strict';

/**
 * @ngdoc overview
 * @name yomanApp
 * @description
 * # yomanApp
 *
 * Main module of the application.
 */
angular
  .module('yomanApp')
  .config(function ($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true).hashPrefix('!');
    $routeProvider
      .when('/', {
        url:'home',
        templateUrl: 'scripts/home/home.html',
        controller: 'homeCtrl',
        controllerAs: 'hm'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
